/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import Modelo.MAlbum;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author csand
 */
public class ControleAlbum {
    Conexao con = new Conexao();
    public void InserirAlbum(MAlbum mod){
        con.conexao();
        try {
            PreparedStatement pst = con.conn.prepareStatement("insert into album (titulo, ano, artista_codartista) values(?,?,?)");
            pst.setString(1, mod.getTitulo());
            pst.setString(2, mod.getAno());
            pst.setInt(3,mod.getCodartista());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Artista Inserido com Sucesso: ");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro na Inserção:\nERRO: "+ex);
        }
        
    }
}
