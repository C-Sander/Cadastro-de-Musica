/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author csand
 */
public class Conexao {
    public Statement stm;
    public ResultSet rs;
    String driver = "com.mysql.jdbc.Driver"; //Classe do driver JDBC    
    String caminho = "jdbc:mysql://localhost/cadastromusicas"; //URL de conexão
    String usuario = "root"; //Usuário do banco
    String senha = "1234"; //Senha de conexão
    public Connection conn;
    
    
    public void conexao(){        
        try {
            System.setProperty("jdbc.Drivers", driver);
            conn = DriverManager.getConnection(caminho, usuario, senha);
            //JOptionPane.showMessageDialog(null, "Conectado com sucesso! ");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro de Conexao!\n Erro: " +ex.getMessage());
        }
       
        }
    public void executaSQL(String sql){
        try {
            stm = conn.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro no ExecutaSQL!\n Erro: " +ex.getMessage());
        }
        
    }
    public void desconecta(){
        try {
            conn.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Desconecta!\n Erro: " +ex.getMessage());
        }
    }
    
}
