/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import Modelo.MMusica;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author csand
 */
public class ControleMusica {
    Conexao con = new Conexao();
    public void InserirMusica(MMusica mod){
        con.conexao();
        try {
            PreparedStatement pst = con.conn.prepareStatement("insert into musica (titulo, duracao,classificacao, album_codalbum) values(?,?,?,?)");
            pst.setString(1, mod.getTitulo());
            pst.setString(2, mod.getDuracao());
            pst.setString(3, mod.getClassificacao());
            pst.setInt(4,mod.getCodalbum());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Artista Inserido com Sucesso: ");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro na Inserção:\nERRO: "+ex);
        }
        
    }
}
