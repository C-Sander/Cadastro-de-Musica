/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import Controle.Conexao;
import Modelo.MArtista;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author csand
 */
public class ControleArtista {
    Conexao con = new Conexao();
    public void InserirArtista(MArtista mod){
        con.conexao();
        try {
            PreparedStatement pst = con.conn.prepareStatement("insert into artista (nome,generomusical_codgeneromusical) values(?,?)");
            pst.setString(1, mod.getNome());
            pst.setInt(2, mod.getCodgeneromusical());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Artista Inserido com Sucesso: ");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro na Inserção:\nERRO: "+ex);
        }
        
    }
    
}
